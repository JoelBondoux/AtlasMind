import { describe, expect, it, vi } from 'vitest';

const vscodeMock = vi.hoisted(() => ({
  workspaceFolders: undefined as unknown,
  getConfiguration: vi.fn(() => ({
    get: (_key: string, fallback?: unknown) => fallback,
  })),
}));

vi.mock('vscode', () => ({
  workspace: {
    get workspaceFolders() {
      return vscodeMock.workspaceFolders;
    },
    set workspaceFolders(value: unknown) {
      vscodeMock.workspaceFolders = value;
    },
    getConfiguration: vscodeMock.getConfiguration,
  },
}));

import {
  addFileAttribution,
  buildRoadmapStatusMarkdown,
  buildAssistantResponseMetadata,
  buildProjectRunSubTaskArtifacts,
  buildProjectRunSummary,
  buildProjectResponseMetadata,
  buildFollowups,
  diffWorkspaceSnapshots,
  estimateTouchedFiles,
  extractImagePathCandidates,
  getProjectUiConfig,
  detectUserFrustrationSignal,
  isConnectedProviderInventoryPrompt,
  isAutonomousContinuationPrompt,
  isRoadmapStatusPrompt,
  mergeImageAttachments,
  reconcileAssistantResponse,
  resolveSpecialistRoutingPlan,
  resolveAutonomousContinuationGoal,
  resolveAtlasChatIntent,
  resolveProjectExecutionGoal,
  renderAssistantResponseFooter,
  shouldCarryForwardConversationContext,
  summarizeChangedFiles,
  summarizeRoadmapStatus,
  toApprovedProjectPrompt,
  toSerializableAttribution,
  type ProjectRunOutcome,
} from '../../src/chat/participant.ts';
import type { TaskImageAttachment } from '../../src/types.ts';
import type { SessionTranscriptEntry } from '../../src/chat/sessionConversation.ts';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import * as vscode from 'vscode';

function makeSnapshotEntry(relativePath: string, signature: string) {
  return {
    signature,
    relativePath,
    uri: { fsPath: `C:/workspace/${relativePath}` },
  };
}

describe('participant helper logic', () => {
  it('returns project-specific followups', () => {
    const followups = buildFollowups('project');
    expect(followups.map(f => f.label)).toEqual([
      'Review session cost',
      'Save plan to memory',
      'Run another project',
    ]);
  });

  it('returns default followups for freeform requests', () => {
    const followups = buildFollowups(undefined);
    expect(followups.map(f => f.label)).toContain('Turn this into a full project');
  });

  it('returns explicit execution-choice followups when assistant metadata provides them', () => {
    const followups = buildFollowups(undefined, undefined, [
      { label: 'Fix This', prompt: 'Fix this issue in the workspace.' },
      { label: 'Explain Only', prompt: 'Explain only.' },
    ]);

    expect(followups.map(f => f.label)).toEqual(['Fix This', 'Explain Only']);
  });

  it('detects short autonomous continuation prompts', () => {
    expect(isAutonomousContinuationPrompt('Proceed autonomously')).toBe(true);
    expect(isAutonomousContinuationPrompt('continue on the approval workflow')).toBe(true);
    expect(isAutonomousContinuationPrompt('Explain how autonomous runs work')).toBe(false);
  });

  it('reuses the latest substantive user prompt for autonomous continuation', () => {
    const transcript: SessionTranscriptEntry[] = [
      {
        id: '1',
        role: 'user',
        content: 'When AtlasMind prompts for tool use it should offer Bypass Approvals and Autopilot.',
        timestamp: '2026-04-05T10:00:00.000Z',
      },
      {
        id: '2',
        role: 'assistant',
        content: 'I will inspect the approval flow and implement it.',
        timestamp: '2026-04-05T10:00:10.000Z',
      },
    ];

    expect(resolveAutonomousContinuationGoal('Proceed autonomously', transcript)).toBe(
      'When AtlasMind prompts for tool use it should offer Bypass Approvals and Autopilot.',
    );
  });

  it('appends follow-up detail when continuing autonomously', () => {
    const transcript: SessionTranscriptEntry[] = [
      {
        id: '1',
        role: 'user',
        content: 'Wire ToolApprovalManager into the live tool gate.',
        timestamp: '2026-04-05T10:00:00.000Z',
      },
    ];

    expect(resolveAutonomousContinuationGoal('Continue on the approval workflow', transcript)).toBe(
      'Wire ToolApprovalManager into the live tool gate.\n\nAdditional execution instruction: the approval workflow',
    );
  });

  it('extracts explicit project goals for project execution routing', () => {
    expect(resolveProjectExecutionGoal('/project Implement approval bypasses', [])).toBe(
      'Implement approval bypasses',
    );
  });

  it('recognizes natural-language requests to start a project run', () => {
    expect(resolveAtlasChatIntent('Start a project run to refactor the auth workflow', [])).toEqual({
      kind: 'project',
      goal: 'refactor the auth workflow',
    });
  });

  it('recognizes natural-language requests to open AtlasMind settings surfaces', () => {
    expect(resolveAtlasChatIntent('Open AtlasMind Settings', [])).toEqual({
      kind: 'command',
      commandId: 'atlasmind.openSettings',
      summary: 'Opened AtlasMind Settings.',
    });
    expect(resolveAtlasChatIntent('Open the AtlasMind cost panel', [])).toEqual({
      kind: 'command',
      commandId: 'atlasmind.openCostDashboard',
      summary: 'Opened the AtlasMind Cost Dashboard.',
    });
    expect(resolveAtlasChatIntent('Open the AtlasMind ideation board', [])).toEqual({
      kind: 'command',
      commandId: 'atlasmind.openProjectIdeation',
      summary: 'Opened the AtlasMind Project Ideation workspace.',
    });
    expect(resolveAtlasChatIntent('Open Specialist Integrations', [])).toEqual({
      kind: 'command',
      commandId: 'atlasmind.openSpecialistIntegrations',
      summary: 'Opened Specialist Integrations.',
    });
  });

  it('recognizes connected provider and model inventory prompts', () => {
    expect(isConnectedProviderInventoryPrompt('Can you give me a review of all the currently connected providers and models Atlas is talking to?')).toBe(true);
    expect(isConnectedProviderInventoryPrompt('Which LLM providers and models are currently connected?')).toBe(true);
    expect(isConnectedProviderInventoryPrompt('Explain how provider adapters work in the architecture.')).toBe(false);
  });
  it('routes image-generation requests to the specialist integrations workflow', () => {
    expect(resolveAtlasChatIntent('Create an image for an alternative logo suggestion', [])).toEqual({
      kind: 'command',
      commandId: 'atlasmind.openSpecialistIntegrations',
      summary: 'Opened Specialist Integrations for image-generation setup. AtlasMind keeps generated-image workflows separate from routed chat models.',
    });
  });

  it('does not misclassify code-oriented image component requests as specialist image generation', () => {
    expect(resolveAtlasChatIntent('Create a React image component for the settings page', [])).toBeUndefined();
  });

  it('routes image-recognition requests with no attachments to the vision panel', () => {
    expect(resolveSpecialistRoutingPlan('Analyze this screenshot and tell me what is wrong')).toEqual(expect.objectContaining({
      kind: 'command',
      id: 'vision-workflow',
      domain: 'visual-analysis',
      label: 'Vision workflow',
      commandId: 'atlasmind.openVisionPanel',
      summary: 'Opened the AtlasMind Vision Panel so you can attach media and run a dedicated recognition workflow.',
    }));
  });

  it('routes attached image-recognition requests as multimodal execution tasks', () => {
    expect(resolveSpecialistRoutingPlan('Analyze this screenshot and tell me what is wrong', {
      imageAttachmentCount: 1,
      availableModels: [
        {
          providerId: 'openai',
          modelId: 'openai/gpt-4o',
          capabilities: ['chat', 'vision', 'function_calling'],
          specialistDomains: ['visual-analysis'],
        },
      ],
    })).toEqual(
      expect.objectContaining({
        kind: 'task',
        id: 'visual-analysis',
        label: 'Image recognition and visual analysis',
        constraintsPatch: expect.objectContaining({
          budget: 'expensive',
          speed: 'considered',
          preferredProvider: 'openai',
          requiredCapabilities: ['vision'],
        }),
      }),
    );
  });

  it('routes speech and transcription prompts to the voice workflow', () => {
    expect(resolveSpecialistRoutingPlan('Transcribe this meeting audio into text')).toEqual(expect.objectContaining({
      kind: 'command',
      id: 'voice-workflow',
      domain: 'voice',
      label: 'Voice and speech workflow',
      commandId: 'atlasmind.openVoicePanel',
      summary: 'Opened the AtlasMind Voice Panel for a dedicated speech and audio workflow.',
    }));
  });

  it('routes research requests toward specialist research settings and provider bias', () => {
    expect(resolveSpecialistRoutingPlan('Do deep research on current MCP adoption patterns', {
      availableModels: [
        {
          providerId: 'perplexity',
          modelId: 'perplexity/sonar-deep-research',
          capabilities: ['chat', 'reasoning'],
          specialistDomains: ['research'],
        },
      ],
    })).toEqual(
      expect.objectContaining({
        kind: 'task',
        id: 'research',
        constraintsPatch: expect.objectContaining({
          budget: 'expensive',
          speed: 'considered',
          preferredProvider: 'perplexity',
          requiredCapabilities: ['reasoning'],
        }),
      }),
    );
  });

  it('allows specialist routing overrides to pin a preferred provider', () => {
    expect(resolveSpecialistRoutingPlan('Do deep research on current MCP adoption patterns', {
      availableModels: [
        {
          providerId: 'perplexity',
          modelId: 'perplexity/sonar-deep-research',
          capabilities: ['chat', 'reasoning'],
          specialistDomains: ['research'],
        },
        {
          providerId: 'copilot',
          modelId: 'copilot/o4-mini',
          capabilities: ['chat', 'code', 'reasoning'],
          specialistDomains: [],
        },
      ],
      overrides: {
        research: {
          preferredProvider: 'copilot',
        },
      },
    })).toEqual(expect.objectContaining({
      constraintsPatch: expect.objectContaining({
        preferredProvider: 'copilot',
      }),
    }));
  });

  it('routes robotics and simulation prompts to code-and-reasoning specialist execution', () => {
    expect(resolveSpecialistRoutingPlan('Simulate the robot arm kinematics for this control loop')).toEqual(
      expect.objectContaining({
        kind: 'task',
        id: 'robotics',
        constraintsPatch: expect.objectContaining({
          budget: 'expensive',
          speed: 'considered',
          requiredCapabilities: ['reasoning', 'code'],
        }),
      }),
    );

    expect(resolveSpecialistRoutingPlan('Run a Monte Carlo simulation for these failure scenarios')).toEqual(
      expect.objectContaining({
        kind: 'task',
        id: 'simulation',
        constraintsPatch: expect.objectContaining({
          budget: 'expensive',
          speed: 'considered',
          requiredCapabilities: ['reasoning', 'code'],
        }),
      }),
    );
  });

  it('keeps conversation context for explicit follow-up prompts', () => {
    const transcript: SessionTranscriptEntry[] = [
      {
        id: '1',
        role: 'user',
        content: 'Investigate why the Dependabot dependency updates are not merging cleanly.',
        timestamp: '2026-04-08T04:00:00.000Z',
      },
    ];

    expect(shouldCarryForwardConversationContext('Based on the above, fix that in the workspace.', transcript)).toBe(true);
  });

  it('drops stale conversation context for strong subject changes', () => {
    const transcript: SessionTranscriptEntry[] = [
      {
        id: '1',
        role: 'user',
        content: 'Investigate why the Dependabot dependency updates are not merging cleanly.',
        timestamp: '2026-04-08T04:00:00.000Z',
      },
    ];

    expect(shouldCarryForwardConversationContext('Create an image for an alternative logo suggestion.', transcript)).toBe(false);
  });

  it('recognizes roadmap status prompts', () => {
    expect(isRoadmapStatusPrompt('what are the outstanding roadmap items we need to address?')).toBe(true);
    expect(isRoadmapStatusPrompt('explain the roadmap philosophy')).toBe(false);
  });

  it('summarizes roadmap progress using the same counting style as the dashboard', () => {
    const snapshot = summarizeRoadmapStatus([
      {
        path: 'project_memory/roadmap/improvement-plan.md',
        content: ['- ✅ done item', '- pending item', '1. [x] numbered complete', '2. numbered pending'].join('\n'),
      },
    ]);

    expect(snapshot.completed).toBe(2);
    expect(snapshot.total).toBe(4);
    expect(snapshot.outstanding.map(item => item.text)).toEqual(['pending item', 'numbered pending']);
  });

  it('builds a live roadmap status response from roadmap files on disk', async () => {
    const tempRoot = mkdtempSync(path.join(os.tmpdir(), 'atlasmind-roadmap-'));
    const roadmapRoot = path.join(tempRoot, 'project_memory', 'roadmap');
    mkdirSync(roadmapRoot, { recursive: true });
    writeFileSync(path.join(roadmapRoot, 'improvement-plan.md'), ['- ✅ shipped milestone', '- pending milestone'].join('\n'));
    writeFileSync(path.join(roadmapRoot, 'provider-followups.md'), ['1. pending provider task'].join('\n'));

    const originalFolders = (vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders;
    const originalGetConfiguration = vscode.workspace.getConfiguration;
    (vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders = [{ uri: { fsPath: tempRoot, path: tempRoot } }];
    (vscode.workspace as { getConfiguration: typeof vscode.workspace.getConfiguration }).getConfiguration = () => ({
      get: (_key: string, fallback?: unknown) => fallback,
    } as never);

    try {
      const markdown = await buildRoadmapStatusMarkdown('what are the outstanding roadmap items we need to address?');
      expect(markdown).toContain('**1/3** roadmap item(s) marked complete');
      expect(markdown).toContain('**2**.');
      expect(markdown).toContain('project_memory/roadmap/improvement-plan.md');
      expect(markdown).toContain('pending milestone');
      expect(markdown).toContain('pending provider task');
    } finally {
      (vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders = originalFolders;
      (vscode.workspace as { getConfiguration: typeof vscode.workspace.getConfiguration }).getConfiguration = originalGetConfiguration;
      rmSync(tempRoot, { recursive: true, force: true });
    }
  });

  it('recommends the highest-weighted roadmap work when the user asks what to do next', async () => {
    const tempRoot = mkdtempSync(path.join(os.tmpdir(), 'atlasmind-roadmap-priority-'));
    const roadmapRoot = path.join(tempRoot, 'project_memory', 'roadmap');
    mkdirSync(roadmapRoot, { recursive: true });
    writeFileSync(
      path.join(roadmapRoot, 'improvement-plan.md'),
      [
        '- [ ] Harden auth token validation and secrets handling',
        '- [ ] Capture the architecture decision for provider failover',
        '- [ ] Polish the README examples',
      ].join('\n'),
    );

    const originalFolders = (vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders;
    const originalGetConfiguration = vscode.workspace.getConfiguration;
    (vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders = [{ uri: { fsPath: tempRoot, path: tempRoot } }];
    (vscode.workspace as { getConfiguration: typeof vscode.workspace.getConfiguration }).getConfiguration = () => ({
      get: (_key: string, fallback?: unknown) => fallback,
    } as never);

    try {
      const markdown = await buildRoadmapStatusMarkdown('what should we work on next?');
      expect(markdown).toContain('### Recommended Next Work');
      expect(markdown).toContain('Harden auth token validation and secrets handling');
      expect(markdown?.indexOf('Harden auth token validation and secrets handling')).toBeLessThan(
        markdown?.indexOf('Capture the architecture decision for provider failover') ?? Number.MAX_SAFE_INTEGER,
      );
    } finally {
      (vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders = originalFolders;
      (vscode.workspace as { getConfiguration: typeof vscode.workspace.getConfiguration }).getConfiguration = originalGetConfiguration;
      rmSync(tempRoot, { recursive: true, force: true });
    }
  });

  it('normalizes approved project prompts', () => {
    expect(toApprovedProjectPrompt('Implement approval bypasses')).toBe(
      'Implement approval bypasses --approve',
    );
  });

  it('builds assistant metadata with model and execution details', () => {
    const metadata = buildAssistantResponseMetadata(
      'Review the workspace and update the docs',
      {
        agentId: 'default',
        modelUsed: 'copilot/gpt-4.1',
        costUsd: 0.0345,
        inputTokens: 1234,
        outputTokens: 567,
        artifacts: {
          output: 'done',
          outputPreview: 'done',
          toolCallCount: 2,
          toolCalls: [],
          verificationSummary: 'npm run compile passed',
          checkpointedTools: ['writeFile'],
        },
      },
      { hasSessionContext: true, routingContext: { sessionContext: 'Recent panel context' } },
    );

    expect(metadata.modelUsed).toBe('copilot/gpt-4.1');
    expect(metadata.thoughtSummary?.summary).toContain('copilot/gpt-4.1');
    expect(metadata.thoughtSummary?.status).toBeUndefined();
    expect(metadata.thoughtSummary?.bullets).toContain('Selected agent: default.');
    expect(metadata.thoughtSummary?.bullets).toContain('Tool loop used 2 call(s).');
    expect(metadata.thoughtSummary?.bullets).toContain('Usage: 1,234 input token(s), 567 output token(s), $0.0345.');
    expect(metadata.thoughtSummary?.bullets).toContain('Included recent session context when routing the response.');
    expect(metadata.thoughtSummary?.bullets).toContain('Checkpointed tools: writeFile.');
  });

  it('adds routing hints and workspace investigation notes to the thinking summary', () => {
    const metadata = buildAssistantResponseMetadata(
      'The chat sidebar layout is broken and I need help debugging the UI regression.',
      {
        agentId: 'frontend-reviewer',
        modelUsed: 'copilot/gpt-4.1',
        costUsd: 0.0042,
        inputTokens: 321,
        outputTokens: 98,
        artifacts: undefined,
      },
      { routingContext: { sessionContext: 'Current chat panel session' } },
    );

    expect(metadata.thoughtSummary?.bullets).toContain('Selected agent: frontend-reviewer.');
    expect(metadata.thoughtSummary?.bullets).toContain('Routing hints: debugging and root-cause analysis, frontend UI and layout.');
    expect(metadata.thoughtSummary?.bullets).toContain('Workspace investigation bias applied before execution.');
    expect(metadata.thoughtSummary?.bullets).toContain('Usage: 321 input token(s), 98 output token(s), $0.0042.');
    expect(metadata.followupQuestion).toBe('Do you want me to fix this?');
    expect(metadata.suggestedFollowups?.map(item => item.label)).toEqual([
      'Fix This',
      'Explain Only',
      'Fix Autonomously',
    ]);
  });

  it('adds specialist routing notes to the thinking summary when a dedicated route was applied', () => {
    const metadata = buildAssistantResponseMetadata(
      'Do deep research on current MCP adoption patterns',
      {
        agentId: 'default',
        modelUsed: 'perplexity/sonar-deep-research',
        costUsd: 0.011,
        inputTokens: 500,
        outputTokens: 220,
        artifacts: undefined,
      },
      {
        routingContext: {
          specialistRouteLabel: 'research and source-backed retrieval',
          specialistRoutingHint: 'Prefer EXA or deep-research routing.',
        },
      },
    );

    expect(metadata.thoughtSummary?.bullets).toContain('Specialist routing: research and source-backed retrieval.');
  });

  it('does not add execution-choice followups when the user explicitly asked for a fix', () => {
    const metadata = buildAssistantResponseMetadata(
      'Fix the broken chat sidebar layout in the workspace.',
      {
        agentId: 'frontend-reviewer',
        modelUsed: 'copilot/gpt-4.1',
        costUsd: 0.0042,
        inputTokens: 321,
        outputTokens: 98,
        artifacts: undefined,
      },
      { routingContext: { sessionContext: 'Current chat panel session' } },
    );

    expect(metadata.followupQuestion).toBeUndefined();
    expect(metadata.suggestedFollowups).toBeUndefined();
  });

  it('does not add execution-choice followups for terse actionable frustrated prompts', () => {
    const metadata = buildAssistantResponseMetadata(
      'Can you do that for me?',
      {
        agentId: 'default',
        modelUsed: 'copilot/gpt-4.1',
        costUsd: 0.0042,
        inputTokens: 321,
        outputTokens: 98,
        artifacts: undefined,
      },
      {
        routingContext: {
          sessionContext: 'We already established that the broken chat sidebar layout is in the workspace chat panel code and the next step is to fix it.',
          userFrustrationSignal: 'Operator frustration signal (moderate): recover with direct action.',
        },
      },
    );

    expect(metadata.followupQuestion).toBeUndefined();
    expect(metadata.suggestedFollowups).toBeUndefined();
    expect(metadata.thoughtSummary?.bullets).toContain('Operator frustration signal detected; Atlas strengthened direct-action and correction guidance for this turn.');
    expect(metadata.timelineNotes).toEqual([
      expect.objectContaining({
        label: 'Learned from friction',
        tone: 'warning',
      }),
    ]);
  });

  it('detects explicit frustration cues that should trigger adaptive learning', () => {
    expect(detectUserFrustrationSignal('You are not doing what I ask. Can you not do this for me?')).toEqual(
      expect.objectContaining({
        level: 'high',
        matchedCue: 'explicit-frustration',
      }),
    );

    expect(detectUserFrustrationSignal('No, I want the reason Atlas is not acting to be resolved.')).toEqual(
      expect.objectContaining({
        level: 'moderate',
        matchedCue: 'frustrated-correction',
      }),
    );
  });

  it('renders an assistant footer with model and thinking summary', () => {
    const footer = renderAssistantResponseFooter({
      modelUsed: 'copilot/gpt-4.1',
      thoughtSummary: {
        label: 'Thinking summary',
        summary: 'High-reasoning code task routed to copilot/gpt-4.1.',
        status: 'verified',
        statusLabel: '[Red->Green observed]',
        bullets: ['Tool loop used 1 call(s).'],
      },
    });

    expect(footer).toContain('_Model: copilot/gpt-4.1_');
    expect(footer).toContain('**Thinking summary:** High-reasoning code task routed to copilot/gpt-4.1.');
    expect(footer).toContain('**Red-to-green:** [Red->Green observed]');
    expect(footer).toContain('- Tool loop used 1 call(s).');
  });

  it('renders follow-up execution choices in the assistant footer', () => {
    const footer = renderAssistantResponseFooter({
      followupQuestion: 'Do you want me to fix this?',
      suggestedFollowups: [
        { label: 'Fix This', prompt: 'Fix this issue.' },
        { label: 'Explain Only', prompt: 'Explain only.' },
      ],
    });

    expect(footer).toContain('**Next step:** Do you want me to fix this?');
    expect(footer).toContain('- Fix This');
    expect(footer).toContain('- Explain Only');
  });

  it('renders session timeline notes in the assistant footer', () => {
    const footer = renderAssistantResponseFooter({
      modelUsed: 'copilot/gpt-4.1',
      timelineNotes: [
        {
          label: 'Learned from friction',
          summary: 'Atlas updated this workspace session with stronger direct-recovery guidance after the operator signaled frustration on this turn.',
          tone: 'warning',
        },
      ],
    });

    expect(footer).toContain('**Session timeline:**');
    expect(footer).toContain('- Learned from friction: Atlas updated this workspace session with stronger direct-recovery guidance after the operator signaled frustration on this turn.');
  });

  it('adds a red-to-green cue when TDD evidence is present', () => {
    const metadata = buildAssistantResponseMetadata(
      'Fix the auth redirect bug and update the implementation.',
      {
        agentId: 'backend-engineer',
        modelUsed: 'copilot/gpt-4.1',
        costUsd: 0.0123,
        inputTokens: 210,
        outputTokens: 80,
        artifacts: {
          output: 'done',
          outputPreview: 'done',
          toolCallCount: 2,
          toolCalls: [],
          tddStatus: 'verified',
          tddSummary: 'Observed a failing relevant test signal before implementation writes and a passing verification signal after the change.',
          checkpointedTools: [],
        },
      },
    );

    expect(metadata.thoughtSummary?.status).toBe('verified');
    expect(metadata.thoughtSummary?.statusLabel).toBe('[Red->Green observed]');
    expect(metadata.thoughtSummary?.bullets).toContain('Red-to-green: [Red->Green observed].');
    expect(metadata.thoughtSummary?.bullets).toContain('TDD evidence: Observed a failing relevant test signal before implementation writes and a passing verification signal after the change..');
  });

  it('persists follow-up policy snapshots into assistant metadata', () => {
    const metadata = buildAssistantResponseMetadata(
      'Review the workspace and update the docs',
      {
        agentId: 'default',
        modelUsed: 'copilot/gpt-4.1',
        costUsd: 0.0345,
        inputTokens: 1234,
        outputTokens: 567,
        artifacts: undefined,
      },
      {
        policies: [
          { source: 'personality', label: 'Saved personality profile', summary: 'Direct, pragmatic, and specific.' },
          { source: 'project-soul', label: 'Project soul', summary: 'Build a safe and reviewable coding agent.' },
        ],
      },
    );

    expect(metadata.policies).toEqual([
      { source: 'personality', label: 'Saved personality profile', summary: 'Direct, pragmatic, and specific.' },
      { source: 'project-soul', label: 'Project soul', summary: 'Build a safe and reviewable coding agent.' },
    ]);
  });

  it('reconciles partial streamed text with a different final response', () => {
    expect(reconcileAssistantResponse(
      'I will inspect the code path.',
      'The response was getting dropped after the first streamed chunk.',
    )).toEqual({
      additionalText: '\n\nThe response was getting dropped after the first streamed chunk.',
      transcriptText: 'I will inspect the code path.\n\nThe response was getting dropped after the first streamed chunk.',
    });
  });

  it('reconciles prefixed streamed text without duplicating the suffix', () => {
    expect(reconcileAssistantResponse(
      'AtlasMind ',
      'AtlasMind completed the response.',
    )).toEqual({
      additionalText: 'completed the response.',
      transcriptText: 'AtlasMind completed the response.',
    });
  });

  it('describes project mode as multiple routed models', () => {
    const metadata = buildProjectResponseMetadata('Ship the new chat bubble metadata');

    expect(metadata.modelUsed).toBe('multiple routed models');
    expect(metadata.thoughtSummary?.summary).toContain('different models');
  });

  it('persists TDD artifact metadata into project run artifacts', () => {
    const artifacts = buildProjectRunSubTaskArtifacts([
      {
        subTaskId: 'fix-auth',
        title: 'Fix auth regression',
        status: 'completed',
        output: 'Updated auth logic.',
        costUsd: 0.01,
        durationMs: 1200,
        role: 'backend-engineer',
        dependsOn: [],
        artifacts: {
          output: 'Updated auth logic.',
          outputPreview: 'Updated auth logic.',
          toolCallCount: 2,
          toolCalls: [],
          verificationSummary: 'PASS: npm run test (exit 0)',
          tddStatus: 'verified',
          tddSummary: 'Observed a failing relevant test signal before implementation writes and a passing verification signal after the change.',
          checkpointedTools: [],
          changedFiles: [],
        },
      },
    ]);

    expect(artifacts[0]?.tddStatus).toBe('verified');
    expect(artifacts[0]?.tddSummary).toContain('failing relevant test signal');
  });

  it('reads valid project UI settings and floors them to positive integers', () => {
    const configuration = {
      get: vi.fn((key: string) => {
        const values: Record<string, number> = {
          projectApprovalFileThreshold: 18.9,
          projectEstimatedFilesPerSubtask: 3.2,
          projectChangedFileReferenceLimit: 7.8,
        };
        return values[key];
      }),
    };

    expect(getProjectUiConfig(configuration)).toEqual({
      approvalFileThreshold: 18,
      estimatedFilesPerSubtask: 3,
      changedFileReferenceLimit: 7,
      runReportFolder: 'project_memory/operations',
    });
  });

  it('falls back to defaults when project UI settings are invalid', () => {
    const configuration = {
      get: vi.fn((key: string) => {
        const values: Record<string, number> = {
          projectApprovalFileThreshold: 0,
          projectEstimatedFilesPerSubtask: -1,
          projectChangedFileReferenceLimit: Number.NaN,
        };
        return values[key];
      }),
    };

    expect(getProjectUiConfig(configuration)).toEqual({
      approvalFileThreshold: 12,
      estimatedFilesPerSubtask: 2,
      changedFileReferenceLimit: 5,
      runReportFolder: 'project_memory/operations',
    });
  });

  it('uses explicit run report folder setting when provided', () => {
    const configuration = {
      get: vi.fn((key: string) => {
        const values: Record<string, unknown> = {
          projectApprovalFileThreshold: 12,
          projectEstimatedFilesPerSubtask: 2,
          projectChangedFileReferenceLimit: 5,
          projectRunReportFolder: 'project_memory/custom_reports',
        };
        return values[key] as string | number;
      }),
    };

    expect(getProjectUiConfig(configuration)).toEqual({
      approvalFileThreshold: 12,
      estimatedFilesPerSubtask: 2,
      changedFileReferenceLimit: 5,
      runReportFolder: 'project_memory/custom_reports',
    });
  });

  it('estimates touched files using the configured multiplier', () => {
    expect(estimateTouchedFiles(4, 3)).toBe(12);
    expect(estimateTouchedFiles(0, 3)).toBe(1);
    expect(estimateTouchedFiles(2, 0)).toBe(2);
  });

  it('diffs snapshots into created, modified, and deleted files', () => {
    const baseline = new Map([
      ['a.ts', makeSnapshotEntry('a.ts', '1:10')],
      ['b.ts', makeSnapshotEntry('b.ts', '1:10')],
    ]);
    const current = new Map([
      ['a.ts', makeSnapshotEntry('a.ts', '2:10')],
      ['c.ts', makeSnapshotEntry('c.ts', '1:10')],
    ]);

    expect(diffWorkspaceSnapshots(baseline, current)).toEqual([
      {
        relativePath: 'a.ts',
        status: 'modified',
        uri: { fsPath: 'C:/workspace/a.ts' },
      },
      {
        relativePath: 'b.ts',
        status: 'deleted',
      },
      {
        relativePath: 'c.ts',
        status: 'created',
        uri: { fsPath: 'C:/workspace/c.ts' },
      },
    ]);
  });

  it('summarizes changed file counts by status', () => {
    expect(summarizeChangedFiles([
      { relativePath: 'a.ts', status: 'created' },
      { relativePath: 'b.ts', status: 'modified' },
      { relativePath: 'c.ts', status: 'modified' },
      { relativePath: 'd.ts', status: 'deleted' },
    ])).toBe('created 1, modified 2, deleted 1');
  });

  it('tracks and serializes file attribution by subtask title', () => {
    const attribution = new Map<string, Set<string>>();
    addFileAttribution(attribution, 'Scaffold API', [
      { relativePath: 'src/api.ts', status: 'created' },
      { relativePath: 'src/routes.ts', status: 'modified' },
    ]);
    addFileAttribution(attribution, 'Add tests', [
      { relativePath: 'src/api.ts', status: 'modified' },
      { relativePath: 'tests/api.test.ts', status: 'created' },
    ]);

    expect(toSerializableAttribution(attribution)).toEqual({
      'src/api.ts': ['Add tests', 'Scaffold API'],
      'src/routes.ts': ['Scaffold API'],
      'tests/api.test.ts': ['Add tests'],
    });
  });

  it('builds a stable project run summary payload', () => {
    const summary = buildProjectRunSummary(
      {
        id: 'plan-1',
        goal: 'Build feature X',
        subTaskResults: [
          {
            subTaskId: 'api',
            title: 'Build API',
            status: 'completed',
            output: 'done',
            costUsd: 0.1,
            durationMs: 1000,
          },
        ],
        synthesis: 'final',
        totalCostUsd: 0.1,
        totalDurationMs: 1000,
      },
      [{ relativePath: 'src/api.ts', status: 'created' }],
      new Map<string, Set<string>>([
        ['src/api.ts', new Set(['Build API'])],
      ]),
      '2026-04-03T10:00:00.000Z',
    );

    expect(summary.id).toBe('plan-1');
    expect(summary.goal).toBe('Build feature X');
    expect(summary.startedAt).toBe('2026-04-03T10:00:00.000Z');
    expect(summary.fileAttribution).toEqual({ 'src/api.ts': ['Build API'] });
    expect(summary.subTaskResults).toHaveLength(1);
    expect(summary.subTaskArtifacts).toEqual([
      expect.objectContaining({
        subTaskId: 'api',
        title: 'Build API',
        status: 'completed',
        toolCallCount: 0,
        changedFiles: [],
      }),
    ]);
  });

  // -- Outcome-aware follow-ups -------------------------------------------

  it('returns failure-oriented followups when project has failures', () => {
    const outcome: ProjectRunOutcome = {
      hasFailures: true,
      hasChangedFiles: true,
      failedSubtaskTitles: ['Build API'],
    };
    const followups = buildFollowups('project', outcome);
    const labels = followups.map(f => f.label);
    expect(labels).toContain('Retry the project');
    expect(labels).toContain('Diagnose failures');
  });

  it('returns change-aware followups when project changed files without failures', () => {
    const outcome: ProjectRunOutcome = {
      hasFailures: false,
      hasChangedFiles: true,
      failedSubtaskTitles: [],
    };
    const followups = buildFollowups('project', outcome);
    expect(followups.map(f => f.label)).toContain('Add tests');
  });

  it('returns default project followups when run succeeded with no file changes', () => {
    const outcome: ProjectRunOutcome = {
      hasFailures: false,
      hasChangedFiles: false,
      failedSubtaskTitles: [],
    };
    const followups = buildFollowups('project', outcome);
    expect(followups.map(f => f.label)).toContain('Run another project');
  });

  it('returns default project followups when no outcome is provided', () => {
    const followups = buildFollowups('project');
    expect(followups.map(f => f.label)).toEqual([
      'Review session cost',
      'Save plan to memory',
      'Run another project',
    ]);
  });

  // -- Edge-case gating -------------------------------------------------------

  it('summarizes an empty changed file list as all-zero counts', () => {
    expect(summarizeChangedFiles([])).toBe('created 0, modified 0, deleted 0');
  });

  it('approval threshold: estimateTouchedFiles exceeds default threshold with 10 subtasks', () => {
    const config = getProjectUiConfig({ get: vi.fn().mockReturnValue(undefined) });
    const estimated = estimateTouchedFiles(10, config.estimatedFilesPerSubtask);
    // 10 subtasks × 2 files default = 20, which exceeds the default threshold of 12
    expect(estimated).toBeGreaterThan(config.approvalFileThreshold);
  });

  it('no-op run: estimateTouchedFiles is within default threshold with 2 subtasks', () => {
    const config = getProjectUiConfig({ get: vi.fn().mockReturnValue(undefined) });
    const estimated = estimateTouchedFiles(2, config.estimatedFilesPerSubtask);
    // 2 × 2 = 4, well within the default threshold of 12
    expect(estimated).toBeLessThanOrEqual(config.approvalFileThreshold);
  });

  it('extracts inline image path candidates from quoted and unquoted prompt text', () => {
    expect(extractImagePathCandidates(
      'Please inspect "media/mockup.png" and screenshots/home page.jpg plus docs/diagram.webp',
    )).toEqual([
      'media/mockup.png',
      'screenshots/home page.jpg',
      'docs/diagram.webp',
    ]);
  });

  it('merges explicit and inline image attachments without duplicates', () => {
    const explicit: TaskImageAttachment[] = [
      { source: 'media/mockup.png', mimeType: 'image/png', dataBase64: 'abc' },
    ];
    const inline: TaskImageAttachment[] = [
      { source: 'media/mockup.png', mimeType: 'image/png', dataBase64: 'abc' },
      { source: 'docs/diagram.webp', mimeType: 'image/webp', dataBase64: 'def' },
    ];

    expect(mergeImageAttachments(explicit, inline)).toEqual([
      { source: 'media/mockup.png', mimeType: 'image/png', dataBase64: 'abc' },
      { source: 'docs/diagram.webp', mimeType: 'image/webp', dataBase64: 'def' },
    ]);
  });

  it('falls back to follow-up detail when no prior substantive user prompt exists', () => {
    expect(resolveAutonomousContinuationGoal('Continue on tests', [])).toBe('tests');
  });
});
