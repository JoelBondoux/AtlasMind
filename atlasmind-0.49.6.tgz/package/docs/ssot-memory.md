# SSOT Memory System

## Overview

The Single Source of Truth (SSOT) is a folder-based memory system that stores all project knowledge in a structured hierarchy. The orchestrator retrieves only the relevant slices for each agent, keeping context windows focused and costs low.

## Folder Structure

```
project_memory/
├── project_soul.md       The living identity document for the project
├── architecture/         System design documents and diagrams
├── roadmap/              Feature plans, milestones, and priorities
├── decisions/            Architecture Decision Records (ADRs)
├── misadventures/        Failed approaches and lessons learned
├── ideas/                Unstructured brainstorms and proposals
├── domain/               Domain knowledge, glossary, business rules
├── operations/           Runbooks, deployment procedures, scripts
├── agents/               Per-agent configuration and custom prompts
├── skills/               Skill definitions and tool schemas
└── index/                Embeddings index for hybrid keyword + hash-vector retrieval
```

## Folder Descriptions

### `project_soul.md`
The identity document. Contains project type, vision, principles, and links to key decisions. Created by the bootstrapper and updated as the project evolves.

AtlasMind now reads a compact summary of `project_soul.md` into the always-on workspace identity prompt for every chat turn. That summary is paired with the saved Atlas Personality Profile so the project identity and operator preferences are both present even when the current request does not explicitly mention memory.

When Atlas detects explicit operator frustration during chat, it also updates the saved workspace Personality Profile, raises chat carry-forward settings if the workspace was retaining too little recent context, and writes the learned behavior into `operations/operator-feedback.md`. That gives Atlas both a live prompt-level correction and a retrievable SSOT record of the preference for future turns.

### `architecture/`
System design docs: component diagrams, data flow diagrams, API contracts, database schemas.

### `roadmap/`
Feature plans with status tracking. Milestones, sprints, priorities, and the developer-facing backlog AtlasMind should consult when deciding what to do next.

Bootstrap and import now both create `roadmap/improvement-plan.md` by default. That file is intentionally simple: developers can keep adding checklist bullets, reorder them to express weighted priority, and let AtlasMind treat the top of the list as stronger planning guidance while still factoring in criticality, security, and architectural impact.

### `decisions/`
Architecture Decision Records following the format:
- **Title**: Short description
- **Status**: Proposed / Accepted / Deprecated / Superseded
- **Context**: Why the decision was needed
- **Decision**: What was decided
- **Consequences**: Trade-offs and implications

### `misadventures/`
Failed approaches documented so they are not repeated. Each entry records:
- What was attempted
- Why it failed
- What was learned

### `ideas/`
Unstructured space for brainstorming. No format requirements.

### `domain/`
Domain-specific knowledge: glossary, business rules, entity relationships, external system documentation.

### `operations/`
Deployment procedures, environment setup, monitoring, incident response.

AtlasMind also records durable operator-feedback notes here when chat detects explicit frustration with advice-only responses. The current note path is `operations/operator-feedback.md`, and it captures the learned recovery rule plus any workspace-level context-retention adjustments so future retrieval can bias toward direct corrective action.

### `agents/`
Per-agent configuration files. Each agent can have a markdown file defining its custom system prompt, behaviour rules, and allowed skills.

### `skills/`
Skill definitions including JSON Schemas for tool parameters.

### `index/`
Generated embeddings index for hybrid keyword + hash-vector retrieval. Not manually edited.

## Memory Entry Format

Each indexed entry has:

```typescript
interface MemoryEntry {
  path: string;       // Relative path within SSOT
  title: string;      // Document title
  tags: string[];     // Categorisation tags
  lastModified: string; // ISO 8601 timestamp
  snippet: string;    // First ~200 chars for preview
  sourcePaths?: string[]; // Source files or SSOT notes this entry summarizes
  sourceFingerprint?: string; // Fingerprint of the upstream source set
  bodyFingerprint?: string; // Fingerprint of the stored note body
  documentClass?: 'project-soul' | 'architecture' | 'roadmap' | 'decision' | 'misadventure' | 'idea' | 'domain' | 'operations' | 'agent' | 'skill' | 'index' | 'other';
  evidenceType?: 'manual' | 'imported' | 'generated-index';
  embedding?: number[]; // Internal hashed vector used for retrieval
}
```

## Retrieval

### Hybrid Keyword + Hash-Vector Search
Memory retrieval uses a **hybrid** approach combining lightweight hash-based embeddings with keyword scoring — it is not a neural/semantic search.

1. User query is tokenized and embedded using a deterministic hash function.
2. Candidate entries are scored by cosine similarity, lexical keyword overlap, document class, evidence type, and freshness.
   - Planning-oriented prompts such as “what should we work on next?” now bias toward roadmap, decision, architecture, and project-soul entries so Atlas sees the intended backlog before proposing the next slice of work.
3. Top-k entries returned ranked by combined score.
4. The orchestrator treats memory as a retrieval layer: summary-safe requests use the ranked memory slices directly, while exact or current-state requests use source-backed memory entries to locate and attach live file excerpts.

### Current Implementation
At activation, AtlasMind indexes text-like SSOT files (`.md`, `.txt`, `.json`, `.yml`, `.yaml`) into in-memory `MemoryEntry` objects and generates a local hashed embedding vector for each entry.

Query ranking combines:
- cosine similarity between the query embedding and entry embedding
- Title match: +3 per term
- Snippet match: +1 per term
- Path match: +2 per term
- Tag match: +2 per term
- Source-path overlap for entries that point back to authoritative files
- Document-class weighting so generated indexes are deprioritized for exact-status questions while architecture, roadmap, decision, and operations notes stay prominent when appropriate
- Freshness weighting so newer imported notes outrank stale summaries when the lexical match is otherwise similar

Results are returned in descending score order.

Query results are clamped to a maximum of **50 entries** regardless of the `maxResults` parameter.

## Writing & Persistence

### Agent Writes
Agents write memory entries via the **`memory-write`** skill. Every write is:

1. **Path-validated** — must be a relative SSOT path with a text-file extension (`.md`, `.txt`, `.json`, `.yml`, `.yaml`). Absolute paths, `..` traversal, and non-text extensions are rejected.
2. **Field-validated** — title ≤ 200 chars, snippet ≤ 4 000 chars, ≤ 12 tags (50 chars each).
3. **Security-scanned** — content is run through the memory scanner before acceptance. Blocked content (prompt injection, API keys) is rejected immediately with a clear error message.
4. **Persisted to disk** — accepted entries are written as markdown files to the SSOT folder so they survive across sessions.

### Upsert Feedback
`upsert()` returns a `MemoryUpsertResult` with one of three statuses:

| Status | Meaning |
|--------|---------|
| `created` | New entry added to index and written to disk |
| `updated` | Existing entry replaced in index and overwritten on disk |
| `rejected` | Entry was not stored; `reason` field explains why |

### Deleting Entries
The **`memory-delete`** skill removes an entry from the in-memory index and deletes the corresponding file on disk.

### Capacity
- In-memory entry count is capped at **1 000 entries**.
- When the cap is reached, new entries are rejected with a clear message. Existing entries can still be updated.

## Bootstrapping

The `bootstrapProject()` function in `src/bootstrap/bootstrapper.ts`:
1. Reads `atlasmind.ssotPath` setting (default: `project_memory`).
2. Rejects unsafe or non-relative SSOT paths.
3. Warns before modifying an existing SSOT folder.
4. Creates only missing files and folders so existing memory is preserved.
5. Optionally initialises a Git repository.
6. Creates `project_soul.md` with starter template.
7. Seeds `roadmap/bootstrap-plan.md` and `roadmap/improvement-plan.md` so the project starts with both milestone prompts and a developer-editable backlog.
8. Prompts for project type and injects it into the soul file.

If governance scaffolding is enabled and `atlasmind.projectDependencyMonitoringEnabled` is on, bootstrap also adds starter dependency-governance memory entries under `operations/dependency-monitoring.md` and `decisions/dependency-policy.md`. Those files are meant for rationale, exceptions, and review history rather than live automation state.

After activation, AtlasMind first tries to load the configured `atlasmind.ssotPath` when that folder exists in the workspace.

If the configured path is missing, AtlasMind automatically looks for an existing MindAtlas SSOT in one common location:
- `project_memory/` at the workspace root

When startup discovery succeeds, `MemoryManager.loadFromDisk()` indexes that SSOT immediately and the Memory sidebar refreshes without requiring a manual import or reload.

For workspaces that were previously imported into SSOT memory, AtlasMind also runs a freshness check during startup. It rebuilds the same import candidates used by `/import`, compares their source fingerprints against the metadata stored in generated SSOT files, and marks memory stale when those fingerprints drift. When drift is detected, AtlasMind shows a warning notification with an **Update Memory** action, exposes an **Update Project Memory** button in the Memory view title bar, and pins a warning row at the top of the Memory tree until the import is refreshed.

While VS Code stays open, AtlasMind now re-checks freshness after workspace saves, creates, deletes, and renames outside the SSOT folder. If those changes make imported memory stale, AtlasMind automatically reruns the incremental import so project memory catches back up without waiting for a reload or a manual update command.

## Importing Existing Projects

`/import` performs a more considered first-pass ingest over the workspace so AtlasMind starts with more than a thin metadata snapshot.

The import pipeline can generate structured entries such as:
- `architecture/project-overview.md` from README content
- `architecture/dependencies.md` from manifests and scripts
- `architecture/project-structure.md` and `architecture/codebase-map.md` from directory scans
- `architecture/runtime-and-surfaces.md`, `architecture/model-routing.md`, and `architecture/agents-and-skills.md` from the core docs set
- `domain/conventions.md` and `domain/product-capabilities.md`
- `operations/development-workflow.md`, `operations/configuration-reference.md`, and `operations/security-and-safety.md`
- `decisions/development-guardrails.md`, `roadmap/release-history.md`, `roadmap/improvement-plan.md`, `index/import-catalog.md`, and `index/import-freshness.md`

If `project_soul.md` still contains the bootstrap placeholders, import also upgrades it into an initial identity document with a vision, principles, and references into the generated SSOT.

Generated import artifacts now carry a trailing metadata block containing generator version, source paths, and source/body fingerprints. On later `/import` runs AtlasMind compares that metadata so it can:
- refresh entries whose upstream sources changed
- skip entries whose inputs are unchanged
- preserve generated files that were manually edited after import

Those metadata trailers are also loaded into the in-memory `MemoryEntry` objects. Imported notes therefore retain explicit evidence pointers back to their upstream files, which lets AtlasMind use SSOT as a fast summary layer without losing the ability to read live evidence when a prompt requires exactness.

During indexing, AtlasMind now computes each entry's document class and evidence type once and reuses that metadata for both the stored `MemoryEntry` and the embedding source. That keeps ranking metadata and embedding context aligned when the classifier logic changes.

The same fingerprint metadata now powers the startup stale-memory signal and the in-session auto-refresh path, so AtlasMind only offers the Memory view refresh affordance when imported entries are genuinely out of date and can automatically refresh them after non-SSOT workspace edits while the window remains open. In the sidebar, AtlasMind now files indexed notes beneath their SSOT storage folders so larger memory sets stay navigable by area instead of flattening into one long list.

This keeps `/import` incremental instead of behaving like a blind overwrite pass.

## Purging Project Memory

The Project page in AtlasMind Settings includes a destructive **Purge Project Memory** action. That flow:
- asks for a modal confirmation first
- requires the operator to type `PURGE MEMORY`
- deletes the configured SSOT root
- recreates the baseline SSOT scaffold
- reloads the Memory view from disk

This action is intended for deliberate resets, not routine cleanup.

## Security

### Memory Scanner

Every SSOT document is scanned for prompt-injection patterns and credential leakage before being included in model context (`src/memory/memoryScanner.ts`).

AtlasMind also reuses those scanner rules for transient freeform-chat context that is not part of SSOT memory. Recent session carry-forward, native chat history summaries, and attached text snippets are treated as untrusted input and scanned before inclusion in model context. Blocked transient context is dropped entirely; warned transient context is redacted and included only as labeled untrusted data.

**Scan outcomes:**

| Status | Meaning | Effect |
|--------|---------|--------|
| `clean` | No issues found | Entry included normally |
| `warned` | Warning-level issues (e.g. unusual phrasing, zero-width chars, oversized document) | Entry included; `[SECURITY WARNING]` appended to system prompt |
| `blocked` | Error-level issues (instruction-override phrases, jailbreak keywords, hardcoded secrets) | Entry excluded from `queryRelevant` — never sent to the model |

**Rules by category:**

*Instruction-override / prompt injection (error):*
- `pi-ignore-instructions` — "ignore all previous instructions"
- `pi-disregard-instructions` — "disregard previous instructions"
- `pi-forget-instructions` — "forget everything you know"
- `pi-new-instructions` — "your new/real instructions"
- `pi-system-prompt-override` — `[system]: prompt = …` patterns
- `pi-jailbreak` — known jailbreak keywords (DAN, developer mode, etc.)

*Persona / obfuscation (warning):*
- `pi-act-as` — "act as an unrestricted AI" patterns
- `pi-zero-width` — zero-width or bidirectional Unicode characters
- `pi-html-comment` — HTML comments containing instruction keywords

*Credential leakage:*
- `secret-api-key` — error; blocks the entry
- `secret-token` — error; blocks the entry
- `secret-password` — warning; flags but does not block
- `size-limit` — warning; document exceeds 32 KB

Scanning runs on every `loadFromDisk()` pass and on every `upsert()` call that provides content. Scan results are accessible via `MemoryManager.getScanResults()`, `getWarnedEntries()`, and `getBlockedEntries()`.

### Other Safeguards
- Bootstrap paths must remain inside the workspace as safe relative paths.
- Existing SSOT files are preserved instead of being blindly overwritten.
- Secrets and provider credentials are explicitly out of scope for SSOT storage.
- In-memory entry count is capped at **1,000 entries**.
- Individual SSOT documents larger than **64 KB** are skipped during disk loading.
- Upserts beyond the entry cap are rejected with a clear reason (existing entries can still be updated).
- All agent-written content is scanned before acceptance — blocked content is never stored.
- Path validation rejects absolute paths, parent traversal, and non-text extensions.

### Secrets Vault (planned)
- Secrets and API keys are NEVER stored in the SSOT.
- A `vault/` folder (gitignored) can hold encrypted references.
- Redaction rules strip sensitive patterns before sending context to LLMs.

### Redaction Rules
- Regex patterns for API keys, tokens, and passwords are enforced by the memory scanner before context inclusion.
- Blocked entries are never sent to providers.
- Warning-level entries are explicitly marked in the system prompt so the model treats them skeptically.
