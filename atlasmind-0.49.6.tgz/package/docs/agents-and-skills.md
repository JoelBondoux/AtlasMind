# Agents & Skills

## Agents

### What is an Agent?

An agent is a specialised AI persona with a defined role, behaviour rules, model preferences, and skill set. The orchestrator selects the best agent for each task and builds a tailored context bundle.

### Agent Definition

```typescript
interface AgentDefinition {
  id: string;             // Unique identifier
  name: string;           // Display name
  role: string;           // Short role description
  description: string;    // Detailed description
  systemPrompt: string;   // System prompt injected into every request
  allowedModels?: string[]; // Model whitelist (empty = any)
  costLimitUsd?: number;  // Per-request cost cap
  skills: string[];       // Skill IDs this agent can use
  builtIn?: boolean;      // True for agents shipped with the extension (not deletable via UI)
}
```

### Built-in Agents

AtlasMind now ships a small developer-focused built-in set for freeform routing:

| id | Name | Focus |
|---|---|---|
| `default` | Default | Catch-all fallback for general development tasks |
| `workspace-debugger` | Workspace Debugger | Repo-local bugs, regressions, root-cause analysis |
| `frontend-engineer` | Frontend Engineer | UI, layout, webview, and interaction work |
| `backend-engineer` | Backend Engineer | APIs, orchestration logic, data flow, and integrations |
| `code-reviewer` | Code Reviewer | Review, verification, regression risk, and test gaps |
| `security-reviewer` | Security Reviewer | Security gaps, runtime boundaries, auth, secret handling, and test-backed security coverage |

When no more specialised built-in or registered agent wins the ranking pass, the orchestrator falls back to:

| Field | Value |
|---|---|
| id | `default` |
| name | `Default` |
| role | `general assistant` |
| systemPrompt | Action-oriented AtlasMind prompt that treats repo bug reports and fix requests as workspace tasks, prefers repository investigation over support-style triage, and still preserves safe behavior |
| skills | `[]` (all enabled skills are available to the default agent) |

The built-in default agent is intentionally execution-capable. In freeform chat, when no more specialized agent is a better fit, AtlasMind should still inspect the current workspace and work the problem instead of replying as if it were only filing feedback for a future product update. AtlasMind now adds an extra workspace-investigation hint when a freeform prompt looks like a concrete bug report or layout or behavior regression in the current repo. For explicit fix, verification, troubleshooting, reproduction, and similar action-oriented requests, AtlasMind also injects an execution-bias hint that tells the model to use the available tools in the current turn instead of stopping at advisory prose. When those hints are present and tools are available, AtlasMind rejects one no-tool response and re-prompts the model for a tool-backed turn, even if the first answer was generic speculation rather than future-tense narration. AtlasMind now also carries an always-on workspace identity block into every task prompt by combining the saved personality profile with a compact summary of `project_soul.md`, so both the operator's preferences and the project's stated identity remain visible on every turn. Provider timeouts are now treated as hard failures rather than silently retrying the same hung request multiple times, so the chat surface returns control faster when a routed model stalls.

The stock built-in specialists intentionally keep `skills: []`, which means they can use the same enabled skill set as the default agent. They differ by routing metadata and system prompt, not by artificially restricted tool access.

For freeform code work, the built-in agents now also carry a shared tests-first delivery policy:
- The default agent applies a light TDD preference so general code changes favor the smallest relevant automated test first when the task is meaningfully testable, and it should create that minimal spec when the repo does not already have one.
- Workspace Debugger prefers reproducing testable regressions with a failing automated signal before implementation, creating the smallest missing regression test first when needed, and then reporting the failing-to-passing evidence.
- Frontend Engineer prefers the smallest relevant UI or interaction regression test before implementation when practical, but explicitly falls back to strong manual verification for primarily visual work.
- Backend Engineer prefers a red-green-refactor loop for testable behavior, contract, and regression changes, including creating the smallest missing contract or regression spec when coverage is absent.
- Code Reviewer treats missing regression coverage, missing failing-to-passing evidence, and weak verification as primary findings unless direct TDD was not practical, and it should frame the concrete follow-up as adding the smallest missing test or spec.
- Security Reviewer treats code, config, runtime boundaries, and security tests as the authoritative evidence layer, uses docs as context rather than sole proof, and treats mismatches between documentation and implementation as first-class findings.

When AtlasMind observes TDD state for a freeform task, the chat Thinking summary now shows a red-to-green status cue. Verified runs surface observed red-to-green evidence directly in chat, while blocked or missing states are called out visibly instead of being buried in verification prose.

Freeform execution also now emits lightweight live progress updates while a response is still running. In the dedicated chat surface, AtlasMind shows interim thinking-style notes such as agent selection, tool rounds, workspace-investigation retries, and escalation or anti-churn nudges before the final answer replaces those transient updates.

### Agent Selection

The orchestrator ranks enabled agents using a blend of lexical relevance and common development-intent heuristics. It still checks request-token overlap against each agent's role and description, but it also recognizes frequent software-development asks such as debugging, testing, review, architecture, frontend, backend, docs, security, devops, performance, and release work.

Selection behavior:
1. Disabled agents are excluded from consideration.
2. Remaining agents are scored by intent overlap across role, description, system prompt, and explicit skill metadata.
3. Requests that match common development needs add routing boosts for agents whose metadata lines up with those needs.
4. Workspace bug-report style prompts add an extra boost for agents that look investigation-ready.
5. Highest score wins; ties break by agent name.
6. If no enabled registered agent exists, the built-in fallback agent is used.

AtlasMind also exposes part of that route back to the user in the assistant footer. The Thinking summary now includes the selected agent, any detected routing hints, whether the workspace-investigation bias was applied before execution, the completed turn's token and cost usage, and any observed red-to-green TDD status.

### Registering Agents

**Via the Manage Agents panel:**

Open the command palette and run **AtlasMind: Manage Agents**. The panel supports:
- Creating a new agent from the **New Agent** button at the top of the panel (id auto-derived from name; all fields editable)
- Editing an existing user-created agent
- Enabling or disabling any registered agent (including built-ins)
- Deleting a user-created agent (with confirmation)
- Viewing built-in agents (read-only)

Agents created through the panel are persisted to `globalState` and restored on next activation. Disabled-agent state is also persisted and restored. The sidebar agents tree updates immediately.

Model assignment can also be driven from the Models sidebar:
- Provider rows expose an assign action that adds all currently discovered models from that provider to the selected agents' `allowedModels` whitelist.
- Model rows expose an assign action that adds or removes a specific model from the selected agents' explicit whitelist.
- Built-in agent model assignments are persisted separately from user-created agents so they survive restarts without turning built-in agents into editable custom agents.

**Programmatically:**
```typescript
atlas.agentRegistry.register({
  id: 'architect',
  name: 'Architect',
  role: 'system design',
  description: 'Designs system architecture and makes structural decisions.',
  systemPrompt: 'You are a software architect...',
  skills: ['file-read', 'diagram-gen'],
});
```

**From SSOT (planned):**
Agent definitions in `project_memory/agents/*.md` will be auto-loaded.

---

## Ephemeral Sub-Agents (Project Execution)

When a `/project` command is executed, the orchestrator synthesises temporary `AgentDefinition` objects on the fly from each `SubTask.role` — these agents are never registered in the `AgentRegistry`. Supported roles and their system prompts:

| Role | Focus |
|---|---|
| `architect` | System design, scalable structure, patterns |
| `backend-engineer` | Server-side APIs, data layers |
| `frontend-engineer` | Responsive UIs, accessible components |
| `tester` | Test authoring, edge cases, coverage |
| `documentation-writer` | User and developer documentation |
| `devops` | CI/CD pipelines, deployment, infrastructure |
| `data-engineer` | Data models, pipelines, transformations |
| `security-reviewer` | OWASP issues, vulnerability mitigations |
| `general-assistant` | Catch-all for unrecognised roles |

Each sub-agent only receives the skill IDs listed in its `SubTask.skills` array plus the `depOutputs` context block prepended to its user message.

For code-changing `/project` work, AtlasMind now gives these ephemeral agents an explicit autonomous TDD contract:
- Prefer tests first when a subtask changes behavior, fixes a regression, or introduces a new contract.
- Capture the expected behavior in the smallest relevant automated test before implementation when the task is meaningfully testable, creating the smallest missing regression test or spec if the repo does not already have one.
- Block non-test implementation writes until a failing relevant test signal has been observed, either in dependency context or in the current subtask.
- Aim for a red-green-refactor flow, then report which tests changed, what verification ran, and any remaining coverage gaps.
- Fall back to direct verification with an explicit explanation when a subtask is documentation-only, infrastructure-only, or otherwise not realistically testable.

Project execution now runs a preflight preview in chat before orchestration starts:
- Atlas shows the decomposed task table and an estimated file-touch impact.
- Atlas also declares that `/project` will follow a tests-first delivery policy where behavior changes are involved.
- Atlas persists per-subtask TDD telemetry so the Project Run Center can show whether Atlas verified the red signal, got blocked by the gate, or never recorded the required evidence.
- If estimated impact exceeds the configured safety threshold, execution is paused until the user re-runs with `--approve`.
- Atlas snapshots the workspace and reports per-subtask changed-file deltas as subtasks complete, then emits a cumulative final summary at the end.
- Atlas records per-file attribution traces (which subtask titles touched which files) and persists a JSON run summary report in the configured report folder.
- When one or more subtasks fail, Atlas renders a post-run failure banner listing the failed subtask titles, the number of files already modified, and a *View Source Control* button for easy rollback.
- After completion, follow-up chips are outcome-driven: a run with failures surfaces *Retry the project* and *Diagnose failures*; a successful run with changed files surfaces *Add tests*; otherwise the default chips are shown.

---

## Skills

### What is a Skill?

A skill defines a capability that agents can use. Skills have typed parameters (JSON Schema) and a handler module that implements the logic.

### Skill Definition

```typescript
interface SkillDefinition {
  id: string;                          // Unique identifier
  name: string;                        // Display name
  description: string;                 // What the skill does
  parameters: Record<string, unknown>; // JSON Schema for input parameters
  execute: SkillHandler;               // Implementation function
  source?: string;                     // Absolute path (custom skills only)
  builtIn?: boolean;                   // True for extension-shipped skills
  panelPath?: string[];                // Skills tree category or folder path
}

type SkillHandler = (
  params: Record<string, unknown>,
  context: SkillExecutionContext,
) => Promise<string>;
```

`SkillExecutionContext` provides workspace file I/O (`readFile`, `writeFile`, `findFiles`), grep-style text search (`searchInFiles`), directory listing (`listDirectory`), bounded subprocess execution (`runCommand`), git inspection helpers (`getGitStatus`, `getGitDiff`), SSOT memory access (`queryMemory`, `upsertMemory`), safe git-backed patch application (`applyGitPatch`), and workspace observability (`getTestResults`, `getActiveDebugSession`, `listTerminals`), all injected by `extension.ts` so skills remain independently testable.

Risky built-in skills are also filtered by a tool-approval policy before execution. AtlasMind classifies each invocation as readonly, workspace-write, terminal-read, terminal-write, git-read, or git-write, then consults the configured approval mode before allowing the tool to run.

Execution-oriented built-in skills now include a dedicated `docker-cli` helper for container work. Instead of passing arbitrary Docker commands through the generic terminal skill, AtlasMind exposes a separate allow-list for `docker` and `docker compose` inspection and lifecycle operations such as `ps`, `logs`, `inspect`, `compose up`, and `compose down`.

### Operational Boundaries

The execution path is intentionally split so extending AtlasMind does not require editing one giant runtime class:

- `AgentRegistry` manages agent definitions, enablement, and success or failure history.
- `SkillsRegistry` manages skill definitions, security-scan state, and enablement.
- `Orchestrator` owns model routing, tool-loop execution, retries, failover, and final task results.
- `ProjectRunHistory` persists reviewable run telemetry for autonomous workflows.
- `ToolWebhookDispatcher` emits external audit events without becoming a hard dependency of the core tool loop.

That separation is the current answer to scaling the number of agents and tools: operational metadata and extension points stay in their own services, while orchestration only composes them.

### Skill Assignment

- An agent lists skill IDs in its `skills` array.
- If the array is empty, the agent has access to **all** registered and **enabled** skills.
- `SkillsRegistry.getSkillsForAgent(agent)` resolves available, enabled skills.

### Enable / Disable

Each skill can be individually enabled or disabled from the Skills tree view using the eye icon (⊙). The state persists across sessions via `globalState`. A skill with a failed security scan cannot be enabled until the issues are resolved and the skill re-scanned.

### Skills Sidebar Organization

- Built-in skills are grouped under **Built-in Skills** and then sub-categorized by operational area so the bundled tool set does not expand into one flat list.
- Custom skills can live at the root of the Skills sidebar or inside nested custom folders.
- Custom folders are persistent, can be created from the Skills title bar or from an existing folder row, and are reused by create-template, import, and draft flows.
- Imported custom skills now restore on activation together with their folder placement and stored scan state.

### Security Scanning

Every custom skill must pass a security scan before it can be enabled. The scanner checks source text line-by-line against 12 built-in rules:

| Rule | Severity | What it catches |
|---|---|---|
| `no-eval` | error | `eval()` calls |
| `no-function-constructor` | error | `new Function()` |
| `no-child-process-require/import` | error | `require('child_process')` / `from 'child_process'` |
| `no-shell-exec` | error | `exec`, `spawn`, `execSync`, etc. |
| `no-path-traversal` | error | `../` path traversal |
| `no-hardcoded-secret` | error | API keys, tokens, passwords in source |
| `no-process-env` | warning | `process.env` access |
| `no-direct-fetch` | warning | `fetch()`, `axios`, `got` |
| `no-http-require/import` | warning | Node `http`/`https` module |
| `no-fs-direct` | warning | `require('fs')` bypassing context |

Error-level issues **block** enablement. Warning-level issues are flagged but do not block.

Built-in skills are pre-approved and auto-pass at activation.

### Scanner Rule Configurator

Open the scanner rules editor from the Skills panel title bar (gear icon) or via `atlasmind.openScannerRules`. Users can:

- Toggle individual rules on/off.
- Edit severity and message for built-in rules (patterns are read-only to preserve integrity).
- Add custom rules with their own id, pattern (regex), severity, and message.
- Delete custom rules.
- Reset built-in rules to factory defaults.

### Adding Custom Skills

From the Skills panel title bar click **+** (or run `AtlasMind: Add Skill`):

1. **Create template** — scaffolds a `.js` CommonJS skill file in `.atlasmind/skills/` and opens it for editing.
2. **Import .js skill** — opens a file picker; the selected file is scanned first and only imported if no errors are found. The skill starts **disabled** so you can review it before enabling.
3. **Let Atlas draft a skill** — available only when `atlasmind.experimentalSkillLearningEnabled` is enabled. Atlas generates a draft `.js` module with the current routing budget/speed settings, scans it, writes it into `.atlasmind/skills/`, and only imports it if you explicitly confirm. Imported drafts remain **disabled** until you review and enable them.

AtlasMind also exposes **Create Skill Folder** from the Skills view so custom skills can be filed into persistent nested folders before or after import.

Custom skills must export `module.exports.skill` (or `module.exports.default`) as a valid `SkillDefinition` object.

### Experimental Skill Learning

AtlasMind can optionally draft custom skill files for you, but this feature is guarded behind an explicit opt-in setting and repeated warnings.

Safety behavior:
- The setting is disabled by default.
- Enabling it shows a warning about extra token usage and generated-code risk.
- Each generation run shows a second modal warning before any model call is made.
- Generated source is security-scanned before import.
- Imported drafts remain disabled until you manually review and enable them.

This is intended as assisted scaffolding, not autonomous self-trust.

### Registering Skills

```typescript
atlas.skillsRegistry.register({
  id: 'file-read',
  name: 'Read File',
  description: 'Read the contents of a file in the workspace.',
  parameters: {
    type: 'object',
    properties: {
      path: { type: 'string', description: 'Absolute file path' },
    },
    required: ['path'],
  },
  execute: async (params, context) => context.readFile(params.path as string),
});
```

### Built-in Skills

The following skills are registered automatically at extension activation (`src/skills/`):

| Skill | Status | Description |
|---|---|---|
| `file-read` | ✅ Implemented | Read file contents (supports optional `startLine`/`endLine` range) |
| `file-write` | ✅ Implemented | Write/create files (workspace-restricted) |
| `file-search` | ✅ Implemented | Search workspace files by glob pattern |
| `text-search` | ✅ Implemented | Search text within UTF-8 workspace files and return matching lines |
| `directory-list` | ✅ Implemented | List files and folders under a workspace directory |
| `file-edit` | ✅ Implemented | Targeted literal search/replace editing with match-count guards |
| `file-delete` | ✅ Implemented | Delete a workspace file |
| `file-move` | ✅ Implemented | Move/rename a workspace file |
| `memory-query` | ✅ Implemented | Search the SSOT (capped at 50 results) |
| `memory-write` | ✅ Implemented | Add/update SSOT entries with validation, security scanning, and disk persistence |
| `memory-delete` | ✅ Implemented | Remove an SSOT entry from index and disk |
| `git-apply-patch` | ✅ Implemented | Validate/apply unified git patches inside the workspace repository |
| `terminal-run` | ✅ Implemented | Execute subprocesses with tiered allow-list (auto-approve, blocked, unknown) and validated string-array arguments |
| `git-status` | ✅ Implemented | Show repository status |
| `git-diff` | ✅ Implemented | Show repository diff |
| `git-commit` | ✅ Implemented | Create a commit after policy approval |
| `git-log` | ✅ Implemented | Query commit log with ref, filePath, and maxCount (capped at 100) |
| `git-branch` | ✅ Implemented | List, create, switch, or delete branches with name validation |
| `rollback-checkpoint` | ✅ Implemented | Restore the most recent automatic pre-write checkpoint |
| `diagnostics` | ✅ Implemented | Retrieve compiler errors/warnings via the VS Code diagnostics API |
| `code-symbols` | ✅ Implemented | AST-aware navigation: list symbols, find references, go to definition |
| `rename-symbol` | ✅ Implemented | Cross-codebase rename via the language server with identifier validation |
| `web-fetch` | ✅ Implemented | Fetch URL content with SSRF protection; 30 s skill timeout |
| `test-run` | ✅ Implemented | Auto-detect framework (vitest/jest/mocha/pytest/cargo) and run tests; 120 s skill timeout |
| `diff-preview` | ✅ Implemented | Combined git status + diff summary with add/modify/delete counts |
| `code-action` | ✅ Implemented | List and apply VS Code quick-fixes and refactorings |
| `workspace-observability` | ✅ Implemented | Snapshot of active debug session, open terminals, and most recent test run results |
| `exa-search` | ✅ Implemented | Search the web using the EXA AI search API; requires EXA API key stored in Specialist Integrations panel |
| `debug-session` | ✅ Implemented | List active VS Code debug sessions and evaluate expressions in the paused debug context |
| `terminal-read` | ✅ Implemented | List open VS Code integrated terminals, summarize the active terminal, and prompt for pasted buffer content when direct reads are unavailable |
| `vscode-extensions` | ✅ Implemented | List installed extensions, identify common developer-tooling extensions, and report forwarded ports from the Ports panel |
| `diagram-gen` | 🔲 Planned | Generate Mermaid diagrams |

### MCP-Sourced Skills

AtlasMind can connect to any [Model Context Protocol](https://modelcontextprotocol.io/) (MCP) server and expose its tools as skills. Open **AtlasMind: Manage MCP Servers** to configure servers, or run **AtlasMind: Import VS Code MCP Servers** to copy compatible entries from the current VS Code profile `mcp.json` and workspace `.vscode/mcp.json` files.

**Skill ID pattern**: `mcp:<serverId>:<toolName>`  
**Source field**: `mcp://<serverId>/<toolName>`

MCP skills are registered in `SkillsRegistry` when a server connects and automatically marked as scan-passed (external process; trust is delegated to the server operator by the user who explicitly configured the connection). They can be individually disabled from the Skills view.

**Transport options**:

| Transport | When to use | Config fields |
|---|---|---|
| `stdio` | Local subprocess (e.g. `npx -y @modelcontextprotocol/server-filesystem`) | `command`, `args`, `env` |
| `http` | Remote server (Streamable HTTP, SSE fallback auto-applied) | `url` |

**Security notes**:
- MCP tools execute in a separate process or remote service — they are not sandboxed within the extension.
- The URL field must use `http://` or `https://`; other schemes are rejected.
- Env vars for stdio servers are merged with the extension host environment; do not store secrets there — use the server's native secret management.
- AtlasMind only imports MCP entries it can reproduce faithfully. VS Code-only fields such as sandbox settings, unresolved `${...}` variables, custom headers, or other unsupported transport options are skipped instead of being downgraded silently.

---

## Context Bundle

For each task, the orchestrator builds a context bundle containing:

1. **Agent system prompt** — from `AgentDefinition.systemPrompt`.
2. **Relevant memory slices** — from `MemoryManager.queryRelevant()`.
3. **Available skills** — from `SkillsRegistry.getSkillsForAgent()`.
4. **User message** — the original request.
5. **Conversation history** — from the chat context.

This bundle is sent to the selected model via the appropriate `ProviderAdapter`.

Current MVP behavior:
- The context bundle is actively built and sent through the orchestrator.
- Skills are resolved via `SkillsRegistry.getSkillsForAgent()`.
- Memory slices come from `MemoryManager.queryRelevant()`.
- When a provider adapter is missing, orchestration returns a safe error response instead of throwing.

## Extension Paths Summary

AtlasMind supports four practical extension paths today:

1. **Add or edit agents** through the Agent Manager panel or `AgentRegistry.register()`.
2. **Add skills** as built-in handlers, imported custom skills, or MCP-backed tools.
3. **Add routed models** by implementing `ProviderAdapter` and registering the provider through the shared runtime.
4. **Add specialist integrations** through dedicated panels when the upstream API is not a good fit for the generic routed chat contract.

The important distinction is that routed providers must support AtlasMind's chat, capability, pricing, and health model, while specialist integrations can remain workflow-specific.
