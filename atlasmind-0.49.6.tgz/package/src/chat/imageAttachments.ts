import * as path from 'path';
import * as vscode from 'vscode';
import type { TaskImageAttachment } from '../types.js';

import { MAX_IMAGE_ATTACHMENTS, MAX_IMAGE_BYTES } from '../constants.js';
const IMAGE_MIME_BY_EXTENSION: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
};

export function extractImagePathCandidates(prompt: string): string[] {
  const candidates = new Set<string>();
  const quotedMatches = prompt.matchAll(/["']([^"'\r\n]+\.(?:png|jpe?g|gif|webp))["']/gi);
  for (const match of quotedMatches) {
    const candidate = normalizeImageCandidate(match[1]);
    if (candidate) {
      candidates.add(candidate);
    }
  }

  const unquotedMatches = prompt.matchAll(/(?:[A-Za-z]:[\\/]|\.{0,2}[\\/]|(?:[\w.-]+[\\/]))[^"'\r\n]+?\.(?:png|jpe?g|gif|webp)\b/gi);
  for (const match of unquotedMatches) {
    const candidate = normalizeImageCandidate(match[0]);
    if (candidate) {
      candidates.add(candidate);
    }
  }

  const bareMatches = prompt.matchAll(/\b[\w.-]+\.(?:png|jpe?g|gif|webp)\b/gi);
  for (const match of bareMatches) {
    const candidate = normalizeImageCandidate(match[0]);
    if (candidate && !hasContainingPath(candidates, candidate)) {
      candidates.add(candidate);
    }
  }

  return [...candidates].slice(0, MAX_IMAGE_ATTACHMENTS);
}

export async function resolveInlineImageAttachments(prompt: string): Promise<TaskImageAttachment[]> {
  const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  if (!workspaceRoot) {
    return [];
  }

  const attachments: TaskImageAttachment[] = [];
  for (const candidate of extractImagePathCandidates(prompt)) {
    const attachment = await loadImageAttachment(candidate, workspaceRoot);
    if (attachment) {
      attachments.push(attachment);
    }
  }
  return attachments;
}

export async function resolvePickedImageAttachments(uris: readonly vscode.Uri[]): Promise<TaskImageAttachment[]> {
  const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  if (!workspaceRoot) {
    return [];
  }

  const attachments: TaskImageAttachment[] = [];
  for (const uri of uris.slice(0, MAX_IMAGE_ATTACHMENTS)) {
    const attachment = await loadImageAttachment(uri.fsPath, workspaceRoot);
    if (attachment) {
      attachments.push(attachment);
    }
  }

  return attachments;
}

type SessionEntryForCarryForward = {
  role: 'user' | 'assistant';
  meta?: {
    promptAttachments?: Array<{
      kind: string;
      source: string;
      mimeType?: string;
      previewDataUri?: string;
    }>;
  };
};

/**
 * Extracts image attachments from the most recent prior user message in the
 * session transcript that contained images. Used to carry forward visual context
 * across follow-up turns when the user has not attached new images.
 *
 * The caller is responsible for passing a transcript that excludes the current
 * in-flight user message (i.e. slice off the last entry if it was just appended).
 *
 * @param priorTranscript - Session entries NOT including the current turn
 * @param maxTurnsBack    - How many prior user turns to search (default: 2)
 */
export function extractSessionCarryForwardImages(
  priorTranscript: SessionEntryForCarryForward[],
  maxTurnsBack = 2,
): TaskImageAttachment[] {
  const userEntries = priorTranscript.filter(entry => entry.role === 'user');
  const lookbackEntries = userEntries.slice(-maxTurnsBack).reverse();

  for (const entry of lookbackEntries) {
    const images: TaskImageAttachment[] = [];
    for (const attachment of entry.meta?.promptAttachments ?? []) {
      if (
        attachment.kind === 'image'
        && attachment.previewDataUri
        && attachment.mimeType
      ) {
        const match = /^data:[^;]+;base64,(.+)$/.exec(attachment.previewDataUri);
        if (match) {
          images.push({
            source: attachment.source,
            mimeType: attachment.mimeType,
            dataBase64: match[1],
          });
        }
      }
    }
    if (images.length > 0) {
      return images;
    }
  }
  return [];
}

export function mergeImageAttachments(
  explicitAttachments: TaskImageAttachment[],
  inlineAttachments: TaskImageAttachment[],
): TaskImageAttachment[] {
  const merged: TaskImageAttachment[] = [];
  const seen = new Set<string>();

  for (const attachment of [...explicitAttachments, ...inlineAttachments]) {
    const key = `${attachment.source}:${attachment.mimeType}:${attachment.dataBase64.length}`;
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    merged.push(attachment);
    if (merged.length >= MAX_IMAGE_ATTACHMENTS) {
      break;
    }
  }

  return merged;
}

async function loadImageAttachment(candidatePath: string, workspaceRoot: string): Promise<TaskImageAttachment | undefined> {
  const resolvedPath = resolvePromptPathCandidate(candidatePath, workspaceRoot);
  if (!resolvedPath) {
    return undefined;
  }

  const mimeType = IMAGE_MIME_BY_EXTENSION[path.extname(resolvedPath).toLowerCase()];
  if (!mimeType) {
    return undefined;
  }

  try {
    const uri = vscode.Uri.file(resolvedPath);
    const stat = await vscode.workspace.fs.stat(uri);
    if (stat.size > MAX_IMAGE_BYTES) {
      return undefined;
    }

    const bytes = await vscode.workspace.fs.readFile(uri);
    return {
      source: vscode.workspace.asRelativePath(uri, false),
      mimeType,
      dataBase64: Buffer.from(bytes).toString('base64'),
    };
  } catch {
    return undefined;
  }
}

function resolvePromptPathCandidate(candidatePath: string, workspaceRoot: string): string | undefined {
  const root = path.resolve(workspaceRoot);
  const resolved = path.isAbsolute(candidatePath)
    ? path.resolve(candidatePath)
    : path.resolve(root, candidatePath);

  if (resolved === root || resolved.startsWith(`${root}${path.sep}`)) {
    return resolved;
  }

  return undefined;
}

function normalizeImageCandidate(value: string | undefined): string | undefined {
  if (!value) {
    return undefined;
  }
  const normalized = value.trim().replace(/[),.;:]+$/g, '');
  return normalized.length > 0 ? normalized : undefined;
}

function hasContainingPath(candidates: Set<string>, candidate: string): boolean {
  for (const existing of candidates) {
    if (existing === candidate) {
      return true;
    }
    if (existing.endsWith(candidate) && existing.length > candidate.length) {
      return true;
    }
    if (existing.endsWith(`/${candidate}`) || existing.endsWith(`\\${candidate}`)) {
      return true;
    }
  }
  return false;
}